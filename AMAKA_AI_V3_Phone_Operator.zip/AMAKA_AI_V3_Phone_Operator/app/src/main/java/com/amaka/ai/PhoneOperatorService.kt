package com.amaka.ai

import android.accessibilityservice.AccessibilityService
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.view.accessibility.AccessibilityService.GLOBAL_ACTION_BACK
import android.view.accessibility.AccessibilityNodeInfo.ACTION_SET_TEXT

class PhoneOperatorService : AccessibilityService() {
    companion object {
        const val ACTION_TAP_TEXT = "com.amaka.ai.TAP_TEXT"
        const val ACTION_TYPE_TEXT = "com.amaka.ai.TYPE_TEXT"
        const val ACTION_BACK = "com.amaka.ai.BACK"
    }

    private val commandReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            when (intent?.action) {
                ACTION_TAP_TEXT -> tapText(intent.getStringExtra("text").orEmpty())
                ACTION_TYPE_TEXT -> typeText(intent.getStringExtra("text").orEmpty())
                ACTION_BACK -> performGlobalAction(GLOBAL_ACTION_BACK)
            }
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        val filter = IntentFilter().apply {
            addAction(ACTION_TAP_TEXT)
            addAction(ACTION_TYPE_TEXT)
            addAction(ACTION_BACK)
        }
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(commandReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        else @Suppress("DEPRECATION") registerReceiver(commandReceiver, filter)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) { /* Commands are explicitly dispatched by the app. */ }
    override fun onInterrupt() {}

    override fun onDestroy() {
        try { unregisterReceiver(commandReceiver) } catch (_: Exception) {}
        super.onDestroy()
    }

    private fun tapText(target: String) {
        if (target.isBlank()) return
        val root = rootInActiveWindow ?: return
        val nodes = root.findAccessibilityNodeInfosByText(target)
        val node = nodes.firstOrNull { it.isClickable } ?: nodes.firstOrNull()
        node?.let {
            var current: AccessibilityNodeInfo? = it
            while (current != null && !current.isClickable) current = current.parent
            current?.performAction(AccessibilityNodeInfo.ACTION_CLICK)
        }
    }

    private fun typeText(value: String) {
        val root = rootInActiveWindow ?: return
        val focused = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
        if (focused != null && focused.isEditable) {
            val args = android.os.Bundle().apply {
                putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, value)
            }
            focused.performAction(ACTION_SET_TEXT, args)
        }
    }
}
