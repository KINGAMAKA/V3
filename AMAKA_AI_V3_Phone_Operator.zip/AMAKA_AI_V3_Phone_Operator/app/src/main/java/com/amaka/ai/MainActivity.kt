package com.amaka.ai

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import android.view.View
import android.view.WindowManager
import android.content.Context
import android.content.BroadcastReceiver
import android.content.IntentFilter
import android.os.Build

class MainActivity : Activity() {
    private lateinit var web: WebView
    private val appUrl = "https://kingamaka.github.io/"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.databaseEnabled = true
        web.settings.javaScriptCanOpenWindowsAutomatically = false
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, url: String): Boolean {
                if (url.startsWith(appUrl)) return false
                return try {
                    startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
                    true
                } catch (_: Exception) { true }
            }
        }
        web.webChromeClient = WebChromeClient()
        web.addJavascriptInterface(AmakaBridge(this), "AMAKA_PHONE")
        setContentView(web)
        web.loadUrl(appUrl)
    }

    override fun onBackPressed() {
        if (::web.isInitialized && web.canGoBack()) web.goBack() else super.onBackPressed()
    }

    class AmakaBridge(private val activity: Activity) {
        private fun toast(s: String) = activity.runOnUiThread {
            Toast.makeText(activity, s, Toast.LENGTH_SHORT).show()
        }

        @JavascriptInterface
        fun isNativeApp(): Boolean = true

        @JavascriptInterface
        fun openWhatsApp() {
            activity.runOnUiThread {
                val launch = activity.packageManager.getLaunchIntentForPackage("com.whatsapp")
                    ?: activity.packageManager.getLaunchIntentForPackage("com.whatsapp.w4b")
                if (launch != null) activity.startActivity(launch)
                else toast("WhatsApp is not installed.")
            }
        }

        @JavascriptInterface
        fun searchYouTube(query: String) {
            val safe = Uri.encode(query.take(180))
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=$safe"))
            activity.runOnUiThread {
                try { activity.startActivity(intent) }
                catch (_: Exception) { toast("Unable to open YouTube search.") }
            }
        }

        @JavascriptInterface
        fun openChromeSearch(query: String) {
            val safe = Uri.encode(query.take(180))
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=$safe"))
            activity.runOnUiThread { activity.startActivity(intent) }
        }

        @JavascriptInterface
        fun openCamera() {
            activity.runOnUiThread {
                try { activity.startActivity(Intent("android.media.action.IMAGE_CAPTURE")) }
                catch (_: Exception) { toast("No camera app found.") }
            }
        }

        @JavascriptInterface
        fun openApp(app: String) {
            val pkg = when (app.lowercase()) {
                "whatsapp" -> "com.whatsapp"
                "whatsapp business" -> "com.whatsapp.w4b"
                "youtube" -> "com.google.android.youtube"
                "chrome" -> "com.android.chrome"
                "camera" -> "camera"
                "settings" -> "settings"
                else -> ""
            }
            activity.runOnUiThread {
                try {
                    val intent = when (pkg) {
                        "camera" -> Intent("android.media.action.IMAGE_CAPTURE")
                        "settings" -> Intent(Settings.ACTION_SETTINGS)
                        else -> activity.packageManager.getLaunchIntentForPackage(pkg)
                    }
                    if (intent != null) activity.startActivity(intent)
                    else toast("That app is not installed or is not available.")
                } catch (_: Exception) { toast("Could not open that app.") }
            }
        }

        @JavascriptInterface
        fun openAccessibilitySettings() {
            activity.runOnUiThread {
                activity.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        }

        @JavascriptInterface
        fun isAccessibilityEnabled(): Boolean {
            val expected = activity.packageName + "/" + PhoneOperatorService::class.java.name
            val enabled = Settings.Secure.getString(
                activity.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
            ) ?: return false
            return enabled.split(':').any { it.equals(expected, ignoreCase = true) }
        }

        // Assisted UI actions: tap visible text or insert text into the currently focused field.
        // The service never presses a "Send", "Pay", "Delete", or other consequential button.
        @JavascriptInterface
        fun tapVisibleText(text: String) {
            val i = Intent(PhoneOperatorService.ACTION_TAP_TEXT)
            i.setPackage(activity.packageName)
            i.putExtra("text", text.take(120))
            activity.sendBroadcast(i)
        }

        @JavascriptInterface
        fun typeIntoFocusedField(text: String) {
            val i = Intent(PhoneOperatorService.ACTION_TYPE_TEXT)
            i.setPackage(activity.packageName)
            i.putExtra("text", text.take(2000))
            activity.sendBroadcast(i)
        }

        @JavascriptInterface
        fun pressBack() {
            val i = Intent(PhoneOperatorService.ACTION_BACK)
            i.setPackage(activity.packageName)
            activity.sendBroadcast(i)
        }

        @JavascriptInterface
        fun showConfirmation(message: String) = toast(message.take(150))
    }
}
