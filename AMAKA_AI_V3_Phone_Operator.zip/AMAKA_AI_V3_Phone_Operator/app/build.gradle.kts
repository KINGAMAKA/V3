plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.amaka.ai"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.amaka.ai"
        minSdk = 26
        targetSdk = 35
        versionCode = 3
        versionName = "3.0"
    }
}
