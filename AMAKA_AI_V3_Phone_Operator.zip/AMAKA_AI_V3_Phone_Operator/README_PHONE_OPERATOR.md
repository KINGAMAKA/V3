# AMAKA AI V3 — Android Phone Operator Starter

## What this package does

This is a native Android companion project for your existing GitHub Pages AMAKA AI website.

- Loads `https://kingamaka.github.io/` inside an Android WebView.
- Exposes a restricted JavaScript bridge called `AMAKA_PHONE`.
- Can launch WhatsApp, WhatsApp Business, YouTube, Chrome, Camera and Android Settings.
- Can open YouTube search results and Google search results.
- Includes an optional Android AccessibilityService for limited assisted UI interaction:
  - tap a visible label/text,
  - insert text into the currently focused editable field,
  - press Android Back.

## What it does NOT do yet

- It does not autonomously understand arbitrary requests; the V2 web chat needs an intent router.
- It does not reliably identify a specific WhatsApp contact or message across every WhatsApp version.
- It does not automatically send WhatsApp messages. This is deliberate: review the recipient and draft, then manually tap Send.
- It does not run as a hidden background agent or record the screen.
- It does not bypass Android permissions.
- It does not include a cloud AI/API. The existing web app remains local-first.

## Why native Android is required

A GitHub Pages website running in Chrome is sandboxed and cannot freely launch, inspect or control other apps. The native companion app provides Android intents and an optional user-enabled AccessibilityService. You must open the AMAKA AI Android app (not the GitHub Pages site in an ordinary Chrome tab) to use the bridge.

## Project structure

```text
AMAKA_AI_V3_Phone_Operator/
├── settings.gradle.kts
├── build.gradle.kts
├── gradle.properties
├── app/
│   ├── build.gradle.kts
│   └── src/main/
│       ├── AndroidManifest.xml
│       ├── java/com/amaka/ai/
│       │   ├── MainActivity.kt
│       │   └── PhoneOperatorService.kt
│       └── res/xml/phone_operator_service.xml
├── web-bridge/
│   └── phone-control-integration.js
└── GEMINI_BUILD_PROMPT.txt
```

## Build on Android

A native Android project generally needs Android Studio or a compatible cloud build service. A GitHub Pages upload alone cannot compile it into an APK.

1. Upload this project folder to a separate GitHub repository, e.g. `amaka-ai-android`.
2. Use Gemini to review/configure the project using `GEMINI_BUILD_PROMPT.txt`.
3. Build the APK using Android Studio or GitHub Actions with Android SDK installed.
4. Install the APK on your Android phone.
5. Open AMAKA AI from its Android app icon. It loads your existing GitHub Pages UI.
6. In the app, open Android Accessibility settings and enable **AMAKA AI Phone Operator** only if you want assisted screen interactions.

## Web app integration

Merge `web-bridge/phone-control-integration.js` into your V2 `app.js` or load it as a script in `index.html`.

The web app can then call:
```js
AMAKA_PHONE_HELPERS.openWhatsApp();
AMAKA_PHONE_HELPERS.searchYouTube("Kanye West");
AMAKA_PHONE_HELPERS.searchWeb("paver suppliers in Zambia");
AMAKA_PHONE_HELPERS.openCamera();
```

Example:
```js
if (AMAKA_PHONE_HELPERS.available()) {
  AMAKA_PHONE_HELPERS.searchYouTube("Kanye West");
} else {
  // Tell the user to open AMAKA AI from its Android app.
}
```

## Security

Accessibility access is powerful. Enable it only on your own device and only if you understand the permission. This starter limits commands and does not automate sending messages, payments, deletion or publishing. Never share an APK that has been modified to capture private screen content or credentials.

## Android 11 note

The project sets `minSdk 26`, so Android 11 (API 30) is supported. Build with a current Android SDK. The project uses a WebView loading the HTTPS GitHub Pages origin.
