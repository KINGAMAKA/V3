/*
 * AMAKA AI V3 — GitHub Pages bridge snippet.
 * Add this script to your V2 page (or merge its functions into app.js).
 * It works ONLY when the page is loaded inside the AMAKA native Android
 * companion app. In ordinary Chrome/GitHub Pages it safely reports unavailable.
 */
window.AMAKA_PHONE_HELPERS = {
  available() {
    return !!(window.AMAKA_PHONE && window.AMAKA_PHONE.isNativeApp &&
      window.AMAKA_PHONE.isNativeApp());
  },
  openWhatsApp() {
    if (!this.available()) return "Phone control requires the AMAKA Android app.";
    window.AMAKA_PHONE.openWhatsApp();
    return "Opening WhatsApp.";
  },
  searchYouTube(query) {
    if (!this.available()) return "Phone control requires the AMAKA Android app.";
    window.AMAKA_PHONE.searchYouTube(query);
    return "Opening YouTube search for: " + query;
  },
  searchWeb(query) {
    if (!this.available()) return "Phone control requires the AMAKA Android app.";
    window.AMAKA_PHONE.openChromeSearch(query);
    return "Opening a web search for: " + query;
  },
  openCamera() {
    if (!this.available()) return "Phone control requires the AMAKA Android app.";
    window.AMAKA_PHONE.openCamera();
    return "Opening camera.";
  },
  openApp(name) {
    if (!this.available()) return "Phone control requires the AMAKA Android app.";
    window.AMAKA_PHONE.openApp(name);
    return "Opening " + name + ".";
  },
  enableAccessibility() {
    if (!this.available()) return "Open this website in the AMAKA Android app first.";
    window.AMAKA_PHONE.openAccessibilitySettings();
    return "Android Accessibility settings opened. Enable AMAKA AI Phone Operator if you choose.";
  },
  tapVisibleText(text) {
    if (!this.available()) return "Phone control requires the AMAKA Android app.";
    if (!window.AMAKA_PHONE.isAccessibilityEnabled()) return "Enable AMAKA AI Phone Operator in Android Accessibility settings first.";
    window.AMAKA_PHONE.tapVisibleText(text);
    return "Trying to select: " + text;
  },
  typeDraft(text) {
    if (!this.available()) return "Phone control requires the AMAKA Android app.";
    if (!window.AMAKA_PHONE.isAccessibilityEnabled()) return "Enable AMAKA AI Phone Operator in Android Accessibility settings first.";
    window.AMAKA_PHONE.typeIntoFocusedField(text);
    return "Draft text inserted into the focused field. Review it yourself before sending.";
  },
  back() {
    if (!this.available()) return "Phone control requires the AMAKA Android app.";
    window.AMAKA_PHONE.pressBack();
    return "Going back.";
  }
};
